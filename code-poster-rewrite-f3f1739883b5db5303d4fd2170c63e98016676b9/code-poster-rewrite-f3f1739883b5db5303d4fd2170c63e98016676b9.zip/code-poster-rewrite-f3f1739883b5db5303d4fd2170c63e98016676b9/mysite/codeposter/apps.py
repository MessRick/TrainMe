from django.apps import AppConfig


class CodeposterConfig(AppConfig):
    name = 'codeposter'
